/*
 * globals.c
 *
 *  Created on: Feb 17, 2022
 *      Author: svigi
 */
#include <stdint.h>

uint8_t mode = 0;
uint16_t aveMeasurement = 0;
uint16_t baseline = 15;
uint16_t alarmLevel = 500;
uint8_t numSamples = 10;
uint8_t numAverages = 50;
