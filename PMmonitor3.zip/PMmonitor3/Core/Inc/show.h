/*
 * show.h
 *
 *  Created on: Feb 25, 2022
 *      Author: svigi
 */

#ifndef INC_SHOW_H_
#define INC_SHOW_H_

#include "ssd1306.h"
#include "globals.h"
#include <string.h>
#include <stdio.h>

void showData ();

#endif /* INC_SHOW_H_ */
