/*
 * alarm.h
 *
 *  Created on: Feb 26, 2022
 *      Author: svigi
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

void alarm();

#endif /* INC_ALARM_H_ */
